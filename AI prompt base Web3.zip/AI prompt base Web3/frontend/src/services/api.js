import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add auth interceptor
api.interceptors.request.use(async (config) => {
  const message = `Authenticate to AI Prompt Marketplace: ${Date.now()}`;
  
  if (window.ethereum && config.requiresAuth) {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      if (accounts[0]) {
        const signature = await window.ethereum.request({
          method: 'personal_sign',
          params: [message, accounts[0]]
        });
        
        config.headers.address = accounts[0];
        config.headers.signature = signature;
        config.headers.message = message;
      }
    } catch (error) {
      console.error('Authentication error:', error);
    }
  }
  
  return config;
});

export const promptService = {
  getPrompts: (params) => api.get('/prompts', { params }),
  getPromptById: (id) => api.get(`/prompts/${id}`),
  createPrompt: (data) => api.post('/prompts', data, { requiresAuth: true }),
  purchasePrompt: (id, data) => api.post(`/prompts/${id}/purchase`, data, { requiresAuth: true })
};

export const generationService = {
  generateOutput: (data) => api.post('/generate', data, { requiresAuth: true })
};

export const originService = {
  // Origin SDK specific methods
  initializeSDK: () => {
    // Initialize Origin SDK
  },
  
  mintNFT: async (metadata) => {
    // Mint NFT using Origin SDK
  },
  
  purchaseNFT: async (tokenId, price) => {
    // Purchase NFT using Origin SDK
  }
};

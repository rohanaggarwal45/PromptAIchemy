import { OriginSDK } from '@originprotocol/origin-sdk';
import { LICENSE_TYPES } from '../../../sdk/licenseConfig';

class OriginSDKService {
  constructor() {
    this.sdk = null;
    this.initialized = false;
  }

  async initialize() {
    if (this.initialized) return;

    try {
      this.sdk = new OriginSDK({
        web3Provider: window.ethereum,
        ipfsGateway: process.env.REACT_APP_IPFS_GATEWAY,
        contractAddresses: {
          promptNFT: process.env.REACT_APP_PROMPT_NFT_ADDRESS
        }
      });

      await this.sdk.init();
      this.initialized = true;
    } catch (error) {
      console.error('Failed to initialize Origin SDK:', error);
      throw error;
    }
  }

  async createPromptListing(data) {
    if (!this.initialized) await this.initialize();

    try {
      const listing = await this.sdk.createListing({
        title: data.title,
        description: data.description,
        price: data.price,
        currency: 'ETH',
        license: LICENSE_TYPES[data.licenseType || 'STANDARD'],
        metadata: {
          promptType: data.promptType,
          tags: data.tags
        }
      });

      return listing;
    } catch (error) {
      console.error('Failed to create prompt listing:', error);
      throw error;
    }
  }

  async purchasePrompt(listingId, options = {}) {
    if (!this.initialized) await this.initialize();

    try {
      const offer = await this.sdk.makeOffer({
        listingId,
        finalizes: options.finalizes || (60 * 60 * 24), // 24 hours
        affiliate: options.affiliate,
        commission: options.commission
      });

      return offer;
    } catch (error) {
      console.error('Failed to purchase prompt:', error);
      throw error;
    }
  }

  async getLicenseInfo(tokenId) {
    if (!this.initialized) await this.initialize();

    try {
      const nft = await this.sdk.getNFT(tokenId);
      return {
        owner: nft.owner,
        license: nft.license,
        royaltyInfo: await this.sdk.getRoyaltyInfo(tokenId)
      };
    } catch (error) {
      console.error('Failed to get license info:', error);
      throw error;
    }
  }

  async verifyLicense(tokenId, account) {
    if (!this.initialized) await this.initialize();

    try {
      const license = await this.sdk.verifyLicense({
        tokenId,
        account
      });

      return {
        isValid: license.isValid,
        expiresAt: license.expiresAt,
        restrictions: license.restrictions
      };
    } catch (error) {
      console.error('Failed to verify license:', error);
      throw error;
    }
  }
}

export default new OriginSDKService();

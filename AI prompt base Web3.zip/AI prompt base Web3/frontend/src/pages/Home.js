import React, { useEffect, useState } from 'react';
import { promptService } from '../services/api';
import { PromptCard } from '../components/PromptCard';

export default function Home() {
  const [featuredPrompts, setFeaturedPrompts] = useState([]);
  const [trendingCreators, setTrendingCreators] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch featured prompts (most purchased)
        const promptsResponse = await promptService.getPrompts({
          sort: 'stats.purchases',
          order: 'desc',
          limit: 6
        });
        setFeaturedPrompts(promptsResponse.data.prompts);

        // In a real app, you'd have an API endpoint for trending creators
        // This is a placeholder using the featured prompts' creators
        const creators = promptsResponse.data.prompts
          .map(prompt => prompt.creator)
          .filter((creator, index, self) => self.indexOf(creator) === index)
          .slice(0, 4);
        setTrendingCreators(creators);

        setLoading(false);
      } catch (error) {
        console.error('Error fetching home data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      {/* Hero Section */}
      <div className="text-center">
        <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
          <span className="block">AI Prompt Marketplace</span>
          <span className="block text-primary-600">Own and Trade Creative Prompts</span>
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Discover, create, and trade powerful AI prompts. Generate unique content with verified prompts and earn royalties from your creations.
        </p>
      </div>

      {/* Featured Prompts */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Prompts</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredPrompts.map((prompt) => (
            <PromptCard key={prompt.tokenId} prompt={prompt} />
          ))}
        </div>
      </div>

      {/* Trending Creators */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Trending Creators</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trendingCreators.map((creator) => (
            <div
              key={creator}
              className="bg-white rounded-lg shadow-md p-6 text-center"
            >
              <div className="h-20 w-20 rounded-full bg-primary-100 mx-auto mb-4 flex items-center justify-center">
                <span className="text-primary-600 text-xl font-bold">
                  {creator.slice(2, 4)}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                {creator.slice(0, 6)}...{creator.slice(-4)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

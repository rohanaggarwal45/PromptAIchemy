import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWeb3 } from '../context/Web3Context';
import { promptService, generationService } from '../services/api';

export default function CreatePrompt() {
  const navigate = useNavigate();
  const { account } = useWeb3();
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [previewOutput, setPreviewOutput] = useState(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    promptText: '',
    promptType: 'text',
    royaltyFee: 250, // 2.5%
    tags: []
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleTagsChange = (e) => {
    const tags = e.target.value.split(',').map(tag => tag.trim());
    setFormData(prev => ({ ...prev, tags }));
  };

  const handlePreview = async () => {
    try {
      setGenerating(true);
      const response = await generationService.generateOutput({
        promptText: formData.promptText,
        type: formData.promptType
      });
      setPreviewOutput(response.data.output);
    } catch (error) {
      console.error('Error generating preview:', error);
      alert('Failed to generate preview');
    } finally {
      setGenerating(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!account) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      setLoading(true);
      await promptService.createPrompt({
        ...formData,
        creator: account
      });
      navigate('/my-prompts');
    } catch (error) {
      console.error('Error creating prompt:', error);
      alert('Failed to create prompt');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Create New Prompt</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Title
          </label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            required
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Prompt Text
          </label>
          <textarea
            name="promptText"
            value={formData.promptText}
            onChange={handleInputChange}
            required
            rows={5}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Prompt Type
          </label>
          <select
            name="promptType"
            value={formData.promptType}
            onChange={handleInputChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          >
            <option value="text">Text</option>
            <option value="image">Image</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Royalty Fee (%)
          </label>
          <input
            type="number"
            name="royaltyFee"
            value={formData.royaltyFee / 100}
            onChange={(e) => handleInputChange({
              target: {
                name: 'royaltyFee',
                value: Math.round(parseFloat(e.target.value) * 100)
              }
            })}
            min="0"
            max="100"
            step="0.1"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Tags (comma-separated)
          </label>
          <input
            type="text"
            value={formData.tags.join(', ')}
            onChange={handleTagsChange}
            placeholder="art, landscape, photo-realistic"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          />
        </div>

        {/* Preview Section */}
        <div className="border rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">Preview Output</h3>
            <button
              type="button"
              onClick={handlePreview}
              disabled={generating || !formData.promptText}
              className="btn-secondary"
            >
              {generating ? 'Generating...' : 'Generate Preview'}
            </button>
          </div>

          {previewOutput && (
            <div className="mt-4">
              {formData.promptType === 'image' ? (
                <img
                  src={previewOutput}
                  alt="Preview"
                  className="w-full h-64 object-cover rounded-lg"
                />
              ) : (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <pre className="whitespace-pre-wrap">{previewOutput}</pre>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={() => navigate('/browse')}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading || !account}
            className="btn-primary"
          >
            {loading ? 'Creating...' : 'Create Prompt'}
          </button>
        </div>
      </form>
    </div>
  );
}

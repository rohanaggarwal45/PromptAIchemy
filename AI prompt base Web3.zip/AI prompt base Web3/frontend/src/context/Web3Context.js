import React, { createContext, useContext, useState, useEffect } from 'react';
import Web3 from 'web3';
import { InjectedConnector } from '@web3-react/injected-connector';

const Web3Context = createContext(null);

export const injected = new InjectedConnector({
  supportedChainIds: [1, 3, 4, 5, 42, 1337] // Supported networks
});

export function Web3Provider({ children }) {
  const [account, setAccount] = useState(null);
  const [web3, setWeb3] = useState(null);
  const [chainId, setChainId] = useState(null);

  useEffect(() => {
    // Check if MetaMask is installed
    if (typeof window.ethereum !== 'undefined') {
      const web3Instance = new Web3(window.ethereum);
      setWeb3(web3Instance);

      // Get the current account
      window.ethereum.request({ method: 'eth_accounts' })
        .then(accounts => {
          if (accounts.length > 0) {
            setAccount(accounts[0]);
          }
        });

      // Get the current chain ID
      web3Instance.eth.getChainId().then(setChainId);

      // Listen for account changes
      window.ethereum.on('accountsChanged', (accounts) => {
        setAccount(accounts[0] || null);
      });

      // Listen for chain changes
      window.ethereum.on('chainChanged', (chainId) => {
        setChainId(parseInt(chainId, 16));
      });
    }
  }, []);

  const connect = async () => {
    try {
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      });
      setAccount(accounts[0]);
    } catch (error) {
      console.error('User rejected connection:', error);
    }
  };

  const disconnect = () => {
    setAccount(null);
  };

  return (
    <Web3Context.Provider value={{ web3, account, chainId, connect, disconnect }}>
      {children}
    </Web3Context.Provider>
  );
}

export function useWeb3() {
  const context = useContext(Web3Context);
  if (!context) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
}

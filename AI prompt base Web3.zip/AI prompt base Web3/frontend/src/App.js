import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Web3Provider } from './context/Web3Context';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import Browse from './pages/Browse';
import PromptDetail from './pages/PromptDetail';
import CreatePrompt from './pages/CreatePrompt';
import MyPrompts from './pages/MyPrompts';

function App() {
  return (
    <Web3Provider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Navigation />
          <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/browse" element={<Browse />} />
              <Route path="/prompt/:id" element={<PromptDetail />} />
              <Route path="/create" element={<CreatePrompt />} />
              <Route path="/my-prompts" element={<MyPrompts />} />
            </Routes>
          </div>
        </div>
      </Router>
    </Web3Provider>
  );
}

export default App;

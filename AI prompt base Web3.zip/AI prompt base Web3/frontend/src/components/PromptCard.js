import React from 'react';
import { Link } from 'react-router-dom';

export function PromptCard({ prompt }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">
            {prompt.title}
          </h3>
          <span className={`px-2 py-1 text-xs rounded-full ${
            prompt.promptType === 'image' 
              ? 'bg-purple-100 text-purple-800'
              : 'bg-blue-100 text-blue-800'
          }`}>
            {prompt.promptType}
          </span>
        </div>
        
        <p className="mt-2 text-gray-600 line-clamp-2">
          {prompt.description}
        </p>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">
              Created by
            </span>
            <span className="text-sm text-gray-900">
              {prompt.creator.slice(0, 6)}...{prompt.creator.slice(-4)}
            </span>
          </div>
          <Link
            to={`/prompt/${prompt.tokenId}`}
            className="text-primary-600 hover:text-primary-700 text-sm font-medium"
          >
            View Details →
          </Link>
        </div>

        {prompt.sampleOutputs && prompt.sampleOutputs.length > 0 && (
          <div className="mt-4">
            <div className="aspect-w-16 aspect-h-9 rounded-md overflow-hidden">
              <img
                src={prompt.sampleOutputs[0].outputUrl}
                alt="Sample output"
                className="object-cover"
              />
            </div>
          </div>
        )}

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">
              Royalty:
            </span>
            <span className="text-sm text-gray-900">
              {(prompt.royaltyFee / 100).toFixed(2)}%
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">
              Views:
            </span>
            <span className="text-sm text-gray-900">
              {prompt.stats.views}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

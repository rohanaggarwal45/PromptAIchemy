const IPFS = require('ipfs-http-client');
const { Buffer } = require('buffer');

class IPFSService {
  constructor(config = {}) {
    this.ipfs = IPFS.create({
      url: config.ipfsNode || 'http://localhost:5001'
    });
    this.gateway = config.ipfsGateway || 'https://ipfs.io/ipfs/';
  }

  /**
   * Upload metadata to IPFS
   */
  async uploadMetadata(metadata) {
    try {
      const buffer = Buffer.from(JSON.stringify(metadata));
      const { cid } = await this.ipfs.add(buffer);
      return {
        cid: cid.toString(),
        url: `${this.gateway}${cid}`,
        ipfsUrl: `ipfs://${cid}`
      };
    } catch (error) {
      console.error('Failed to upload to IPFS:', error);
      throw error;
    }
  }

  /**
   * Upload prompt output (images) to IPFS
   */
  async uploadOutput(output, type) {
    try {
      let buffer;
      if (type === 'image') {
        // For base64 encoded images
        const base64Data = output.replace(/^data:image\/\w+;base64,/, '');
        buffer = Buffer.from(base64Data, 'base64');
      } else {
        buffer = Buffer.from(output);
      }

      const { cid } = await this.ipfs.add(buffer);
      return {
        cid: cid.toString(),
        url: `${this.gateway}${cid}`,
        ipfsUrl: `ipfs://${cid}`
      };
    } catch (error) {
      console.error('Failed to upload output to IPFS:', error);
      throw error;
    }
  }

  /**
   * Get metadata from IPFS
   */
  async getMetadata(cid) {
    try {
      const stream = await this.ipfs.cat(cid);
      let data = '';

      for await (const chunk of stream) {
        data += chunk.toString();
      }

      return JSON.parse(data);
    } catch (error) {
      console.error('Failed to get metadata from IPFS:', error);
      throw error;
    }
  }

  /**
   * Pin content to ensure persistence
   */
  async pinContent(cid) {
    try {
      await this.ipfs.pin.add(cid);
      return true;
    } catch (error) {
      console.error('Failed to pin content:', error);
      throw error;
    }
  }
}

module.exports = IPFSService;

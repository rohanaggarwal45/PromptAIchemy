/**
 * License configuration for AI Prompts
 */
const LICENSE_TYPES = {
  STANDARD: {
    id: 'standard',
    name: 'Standard License',
    description: 'Basic usage rights with attribution required',
    allowCommercialUse: false,
    allowDerivatives: false,
    requireAttribution: true,
    defaultRoyalty: 250 // 2.5%
  },
  COMMERCIAL: {
    id: 'commercial',
    name: 'Commercial License',
    description: 'Full commercial usage rights with attribution',
    allowCommercialUse: true,
    allowDerivatives: false,
    requireAttribution: true,
    defaultRoyalty: 500 // 5%
  },
  ENTERPRISE: {
    id: 'enterprise',
    name: 'Enterprise License',
    description: 'Full rights including derivatives and white-labeling',
    allowCommercialUse: true,
    allowDerivatives: true,
    requireAttribution: false,
    defaultRoyalty: 1000 // 10%
  }
};

const LICENSE_TERMS = {
  ATTRIBUTION: `
    Attribution Requirements:
    1. Credit the original prompt creator
    2. Include the prompt's unique identifier
    3. Link back to the prompt's page on the marketplace
  `,
  COMMERCIAL_USE: `
    Commercial Use Terms:
    1. Right to use the prompt in commercial projects
    2. Right to sell outputs generated from the prompt
    3. Royalties apply to commercial revenue
  `,
  DERIVATIVES: `
    Derivative Works:
    1. Right to modify the original prompt
    2. Right to combine with other prompts
    3. Must maintain the spirit of the original prompt
  `
};

const DEFAULT_LICENSE_DURATION = 365 * 24 * 60 * 60; // 1 year in seconds

module.exports = {
  LICENSE_TYPES,
  LICENSE_TERMS,
  DEFAULT_LICENSE_DURATION
};

const { OriginSDK } = require('@originprotocol/origin-sdk');
const Web3 = require('web3');
const IPFS = require('ipfs-http-client');
const { PromptNFT } = require('../contracts/artifacts/contracts/PromptNFT.sol/PromptNFT.json');

class OriginService {
  constructor(config = {}) {
    this.config = {
      web3Provider: config.web3Provider || process.env.WEB3_PROVIDER,
      contractAddress: config.contractAddress || process.env.PROMPT_NFT_ADDRESS,
      ipfsGateway: config.ipfsGateway || 'https://ipfs.io/ipfs/',
      ipfsNode: config.ipfsNode || 'http://localhost:5001'
    };

    this.origin = new OriginSDK({
      ipfsGateway: this.config.ipfsGateway,
      web3Provider: this.config.web3Provider,
      contractAddresses: {
        promptNFT: this.config.contractAddress
      }
    });

    this.web3 = new Web3(this.config.web3Provider);
    this.contract = new this.web3.eth.Contract(PromptNFT.abi, this.config.contractAddress);
    this.ipfs = IPFS.create({ url: this.config.ipfsNode });
  }

  /**
   * Initialize the Origin SDK and connect to blockchain
   */
  async initialize() {
    try {
      await this.origin.init();
      return true;
    } catch (error) {
      console.error('Failed to initialize Origin SDK:', error);
      throw error;
    }
  }

  /**
   * Upload metadata to IPFS and mint NFT
   */
  async mintPromptNFT(data, account) {
    try {
      // Upload metadata to IPFS
      const metadata = {
        name: data.title,
        description: data.description,
        prompt: {
          text: data.promptText,
          type: data.promptType
        },
        properties: {
          royaltyFee: data.royaltyFee,
          tags: data.tags
        },
        createdAt: new Date().toISOString()
      };

      const { cid } = await this.ipfs.add(JSON.stringify(metadata));
      const tokenURI = `ipfs://${cid}`;

      // Create NFT license using Origin SDK
      const license = await this.origin.createLicense({
        licenseType: 'NFT',
        allowCommercialUse: true,
        allowDerivatives: false,
        requireAttribution: true,
        royaltyBasisPoints: data.royaltyFee
      });

      // Mint NFT
      const mintTx = await this.contract.methods.mintPrompt(
        account,
        data.title,
        data.description,
        data.promptText,
        data.promptType,
        tokenURI,
        data.royaltyFee
      ).send({ from: account });

      // Register NFT with Origin SDK
      await this.origin.registerNFT({
        tokenId: mintTx.events.PromptMinted.returnValues.tokenId,
        contractAddress: this.config.contractAddress,
        license: license.id,
        metadata: {
          tokenURI,
          creator: account
        }
      });

      return {
        tokenId: mintTx.events.PromptMinted.returnValues.tokenId,
        tokenURI,
        license: license.id,
        transaction: mintTx
      };

    } catch (error) {
      console.error('Failed to mint prompt NFT:', error);
      throw error;
    }
  }

  /**
   * Purchase a prompt NFT with licensing terms
   */
  async purchasePrompt(tokenId, buyer, price) {
    try {
      // Get NFT details from Origin SDK
      const nft = await this.origin.getNFT({
        tokenId,
        contractAddress: this.config.contractAddress
      });

      // Create purchase offer
      const offer = await this.origin.createOffer({
        nftId: nft.id,
        buyer,
        price,
        currency: 'ETH'
      });

      // Execute purchase
      const purchaseTx = await this.origin.executePurchase({
        offerId: offer.id,
        buyer
      });

      // Handle royalty payment
      const { creator, royaltyAmount } = await this.contract.methods
        .royaltyInfo(tokenId, price)
        .call();

      if (royaltyAmount > 0) {
        await this.web3.eth.sendTransaction({
          from: buyer,
          to: creator,
          value: royaltyAmount
        });

        // Emit royalty event from contract
        await this.contract.methods.emitRoyaltyPaid(
          tokenId,
          creator,
          buyer,
          royaltyAmount
        ).send({ from: buyer });
      }

      return {
        purchaseId: purchaseTx.id,
        license: nft.license,
        transaction: purchaseTx
      };

    } catch (error) {
      console.error('Failed to purchase prompt:', error);
      throw error;
    }
  }

  /**
   * Get licensing terms for a prompt
   */
  async getLicenseTerms(tokenId) {
    try {
      const nft = await this.origin.getNFT({
        tokenId,
        contractAddress: this.config.contractAddress
      });

      const license = await this.origin.getLicense(nft.license);

      return {
        licenseId: license.id,
        licenseType: license.licenseType,
        allowCommercialUse: license.allowCommercialUse,
        allowDerivatives: license.allowDerivatives,
        requireAttribution: license.requireAttribution,
        royaltyBasisPoints: license.royaltyBasisPoints,
        terms: license.terms
      };

    } catch (error) {
      console.error('Failed to get license terms:', error);
      throw error;
    }
  }

  /**
   * Track royalty payments for a prompt
   */
  async trackRoyalties(tokenId) {
    try {
      // Get all royalty events for the token
      const events = await this.contract.getPastEvents('RoyaltyPaid', {
        filter: { tokenId },
        fromBlock: 0,
        toBlock: 'latest'
      });

      const royalties = events.map(event => ({
        tokenId: event.returnValues.tokenId,
        creator: event.returnValues.creator,
        buyer: event.returnValues.buyer,
        amount: event.returnValues.amount,
        timestamp: event.timestamp
      }));

      return royalties;

    } catch (error) {
      console.error('Failed to track royalties:', error);
      throw error;
    }
  }
}

module.exports = OriginService;

const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("PromptNFT", function () {
  let PromptNFT;
  let promptNFT;
  let owner;
  let creator;
  let buyer;

  beforeEach(async function () {
    [owner, creator, buyer] = await ethers.getSigners();
    PromptNFT = await ethers.getContractFactory("PromptNFT");
    promptNFT = await PromptNFT.deploy();
    await promptNFT.deployed();
  });

  describe("Minting", function () {
    it("Should mint a new prompt NFT", async function () {
      const title = "Test Prompt";
      const description = "A test prompt for generating art";
      const promptText = "A beautiful sunset over the ocean";
      const promptType = "image";
      const tokenURI = "ipfs://test-uri";
      const royaltyFee = 250; // 2.5%

      await expect(
        promptNFT.connect(creator).mintPrompt(
          creator.address,
          title,
          description,
          promptText,
          promptType,
          tokenURI,
          royaltyFee
        )
      )
        .to.emit(promptNFT, "PromptMinted")
        .withArgs(1, creator.address, title, promptType);

      // Verify token ownership
      expect(await promptNFT.ownerOf(1)).to.equal(creator.address);

      // Verify prompt metadata
      const metadata = await promptNFT.getPromptMetadata(1);
      expect(metadata.title).to.equal(title);
      expect(metadata.description).to.equal(description);
      expect(metadata.promptText).to.equal(promptText);
      expect(metadata.promptType).to.equal(promptType);
      expect(metadata.creator).to.equal(creator.address);
    });

    it("Should fail when minting with invalid prompt type", async function () {
      await expect(
        promptNFT.connect(creator).mintPrompt(
          creator.address,
          "Test",
          "Description",
          "Prompt",
          "invalid",
          "uri",
          250
        )
      ).to.be.revertedWith("Invalid prompt type");
    });
  });

  describe("Royalties", function () {
    it("Should set and query royalty info correctly", async function () {
      // Mint a token with 2.5% royalty
      await promptNFT.connect(creator).mintPrompt(
        creator.address,
        "Test",
        "Description",
        "Prompt",
        "image",
        "uri",
        250
      );

      // Check royalty info for a sale price of 100 ETH
      const salePrice = ethers.utils.parseEther("100");
      const [receiver, royaltyAmount] = await promptNFT.royaltyInfo(1, salePrice);

      expect(receiver).to.equal(creator.address);
      expect(royaltyAmount).to.equal(salePrice.mul(250).div(10000)); // 2.5% of sale price
    });
  });

  describe("Ownership Verification", function () {
    it("Should correctly verify prompt ownership", async function () {
      // Mint a token
      await promptNFT.connect(creator).mintPrompt(
        creator.address,
        "Test",
        "Description",
        "Prompt",
        "image",
        "uri",
        250
      );

      // Verify ownership
      expect(await promptNFT.verifyPromptOwnership(creator.address, 1)).to.be.true;
      expect(await promptNFT.verifyPromptOwnership(buyer.address, 1)).to.be.false;
    });
  });
});

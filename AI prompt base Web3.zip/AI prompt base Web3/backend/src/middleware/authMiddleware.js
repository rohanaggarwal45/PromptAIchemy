const Web3 = require('web3');
const logger = require('../utils/logger');

class AuthMiddleware {
  async verifyWalletSignature(req, res, next) {
    try {
      const { address, signature, message } = req.headers;

      if (!address || !signature || !message) {
        return res.status(401).json({ error: 'Missing authentication parameters' });
      }

      const web3 = new Web3(process.env.WEB3_PROVIDER);
      
      // Recover the address from the signature
      const recoveredAddress = web3.eth.accounts.recover(message, signature);

      if (recoveredAddress.toLowerCase() !== address.toLowerCase()) {
        return res.status(401).json({ error: 'Invalid signature' });
      }

      // Attach the verified address to the request
      req.userAddress = address.toLowerCase();
      next();

    } catch (error) {
      logger.error('Authentication error:', error);
      res.status(401).json({ error: 'Authentication failed' });
    }
  }

  async requireCreator(req, res, next) {
    try {
      const { tokenId } = req.params;
      const userAddress = req.userAddress;

      const contract = new web3.eth.Contract(/* ABI and address */);
      const promptData = await contract.methods.getPromptMetadata(tokenId).call();

      if (promptData.creator.toLowerCase() !== userAddress.toLowerCase()) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      next();

    } catch (error) {
      logger.error('Authorization error:', error);
      res.status(403).json({ error: 'Authorization failed' });
    }
  }
}

module.exports = new AuthMiddleware();

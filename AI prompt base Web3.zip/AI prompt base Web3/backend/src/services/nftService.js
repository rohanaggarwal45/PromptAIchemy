const OriginService = require('../../sdk/OriginService');
const IPFSService = require('../../sdk/IPFSService');
const { LICENSE_TYPES } = require('../../sdk/licenseConfig');

class NFTService {
  constructor() {
    this.originService = new OriginService({
      web3Provider: process.env.WEB3_PROVIDER,
      contractAddress: process.env.PROMPT_NFT_ADDRESS
    });

    this.ipfsService = new IPFSService({
      ipfsNode: process.env.IPFS_NODE,
      ipfsGateway: process.env.IPFS_GATEWAY
    });
  }

  /**
   * Create and mint a new prompt NFT
   */
  async createPrompt(data, account) {
    try {
      // Upload sample outputs to IPFS if they exist
      const sampleOutputs = [];
      if (data.sampleOutput) {
        const outputResult = await this.ipfsService.uploadOutput(
          data.sampleOutput,
          data.promptType
        );
        sampleOutputs.push({
          outputType: data.promptType,
          outputUrl: outputResult.url,
          ipfsUrl: outputResult.ipfsUrl
        });
      }

      // Prepare metadata
      const metadata = {
        title: data.title,
        description: data.description,
        promptText: data.promptText,
        promptType: data.promptType,
        sampleOutputs,
        creator: account,
        license: LICENSE_TYPES[data.licenseType || 'STANDARD'],
        tags: data.tags
      };

      // Upload metadata to IPFS
      const metadataResult = await this.ipfsService.uploadMetadata(metadata);

      // Mint NFT with Origin SDK
      const result = await this.originService.mintPromptNFT({
        ...data,
        tokenURI: metadataResult.ipfsUrl
      }, account);

      return {
        ...result,
        metadata: metadata,
        ipfsUri: metadataResult.ipfsUrl
      };

    } catch (error) {
      console.error('Failed to create prompt:', error);
      throw error;
    }
  }

  /**
   * Purchase a prompt NFT with licensing
   */
  async purchasePrompt(tokenId, buyer, price, licenseType = 'STANDARD') {
    try {
      // Verify the prompt exists and get metadata
      const metadata = await this.originService.getLicenseTerms(tokenId);
      
      // Execute purchase with Origin SDK
      const result = await this.originService.purchasePrompt(
        tokenId,
        buyer,
        price
      );

      // Create license certificate
      const licenseData = {
        tokenId,
        buyer,
        purchaseDate: new Date().toISOString(),
        licenseType: LICENSE_TYPES[licenseType],
        transactionHash: result.transaction.transactionHash
      };

      const certificateResult = await this.ipfsService.uploadMetadata(licenseData);

      return {
        ...result,
        licenseCertificate: certificateResult.url
      };

    } catch (error) {
      console.error('Failed to purchase prompt:', error);
      throw error;
    }
  }

  /**
   * Get royalty information for a prompt
   */
  async getRoyaltyInfo(tokenId) {
    try {
      const [licenseTerms, royalties] = await Promise.all([
        this.originService.getLicenseTerms(tokenId),
        this.originService.trackRoyalties(tokenId)
      ]);

      return {
        licenseTerms,
        royalties,
        totalRoyalties: royalties.reduce((sum, r) => sum + Number(r.amount), 0)
      };

    } catch (error) {
      console.error('Failed to get royalty info:', error);
      throw error;
    }
  }
}

module.exports = new NFTService();

const mongoose = require('mongoose');

const promptSchema = new mongoose.Schema({
  tokenId: {
    type: Number,
    required: true,
    unique: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  promptText: {
    type: String,
    required: true
  },
  promptType: {
    type: String,
    enum: ['image', 'text'],
    required: true
  },
  creator: {
    type: String,
    required: true,
    lowercase: true
  },
  tokenURI: {
    type: String,
    required: true
  },
  royaltyFee: {
    type: Number,
    required: true,
    min: 0,
    max: 10000 // basis points (0-100%)
  },
  sampleOutputs: [{
    outputType: String,
    outputUrl: String,
    createdAt: Date
  }],
  stats: {
    views: { type: Number, default: 0 },
    purchases: { type: Number, default: 0 },
    totalRoyalties: { type: Number, default: 0 }
  },
  tags: [String],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Indexes for better query performance
promptSchema.index({ tokenId: 1 });
promptSchema.index({ creator: 1 });
promptSchema.index({ promptType: 1 });
promptSchema.index({ tags: 1 });

// Update the updatedAt timestamp before saving
promptSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Prompt', promptSchema);

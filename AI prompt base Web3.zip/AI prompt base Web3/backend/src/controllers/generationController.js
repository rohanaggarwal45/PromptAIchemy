const { OpenAI } = require('openai');
const { StabilityClient } = require('stability-client');
const logger = require('../utils/logger');

class GenerationController {
  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });

    this.stability = new StabilityClient({
      apiKey: process.env.STABILITY_API_KEY
    });
  }

  async generateOutput(req, res) {
    try {
      const { promptText, type } = req.body;

      if (!promptText) {
        return res.status(400).json({ error: 'Prompt text is required' });
      }

      let output;
      if (type === 'text') {
        output = await this.generateText(promptText);
      } else if (type === 'image') {
        output = await this.generateImage(promptText);
      } else {
        return res.status(400).json({ error: 'Invalid generation type' });
      }

      res.json({ output });

    } catch (error) {
      logger.error('Error generating output:', error);
      res.status(500).json({ error: 'Failed to generate output' });
    }
  }

  async generateText(promptText) {
    try {
      const completion = await this.openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: promptText }],
        max_tokens: 1000
      });

      return completion.choices[0].message.content;

    } catch (error) {
      logger.error('OpenAI API error:', error);
      throw new Error('Text generation failed');
    }
  }

  async generateImage(promptText) {
    try {
      const result = await this.stability.generateImage({
        prompt: promptText,
        steps: 50,
        width: 512,
        height: 512,
        samples: 1
      });

      // Assuming the API returns a URL or Base64 image
      return result.artifacts[0];

    } catch (error) {
      logger.error('Stability API error:', error);
      throw new Error('Image generation failed');
    }
  }
}

module.exports = new GenerationController();

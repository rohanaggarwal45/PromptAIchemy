const Prompt = require('../models/prompt');
const { OriginSDK } = require('@originprotocol/origin-sdk');
const Web3 = require('web3');
const { validationResult } = require('express-validator');
const logger = require('../utils/logger');

class PromptController {
  async createPrompt(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const {
        title,
        description,
        promptText,
        promptType,
        creator,
        royaltyFee,
        tags
      } = req.body;

      // Mint NFT using Origin SDK
      const origin = new OriginSDK();
      const web3 = new Web3(process.env.WEB3_PROVIDER);
      
      const metadata = {
        title,
        description,
        promptText,
        promptType,
        creator,
        royaltyFee,
        tags
      };

      // Upload metadata to IPFS
      const tokenURI = await origin.uploadMetadata(metadata);

      // Mint NFT
      const contract = new web3.eth.Contract(/* ABI and address */);
      const tx = await contract.methods.mintPrompt(
        creator,
        title,
        description,
        promptText,
        promptType,
        tokenURI,
        royaltyFee
      ).send({ from: creator });

      const tokenId = tx.events.PromptMinted.returnValues.tokenId;

      // Save to MongoDB
      const prompt = new Prompt({
        tokenId,
        title,
        description,
        promptText,
        promptType,
        creator,
        tokenURI,
        royaltyFee,
        tags
      });

      await prompt.save();
      res.status(201).json(prompt);

    } catch (error) {
      logger.error('Error creating prompt:', error);
      res.status(500).json({ error: 'Failed to create prompt' });
    }
  }

  async getPrompts(req, res) {
    try {
      const { 
        type,
        creator,
        tags,
        sort = 'createdAt',
        order = 'desc',
        page = 1,
        limit = 10
      } = req.query;

      const query = {};
      if (type) query.promptType = type;
      if (creator) query.creator = creator.toLowerCase();
      if (tags) query.tags = { $in: tags.split(',') };

      const prompts = await Prompt.find(query)
        .sort({ [sort]: order })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit));

      const total = await Prompt.countDocuments(query);

      res.json({
        prompts,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit)),
        total
      });

    } catch (error) {
      logger.error('Error fetching prompts:', error);
      res.status(500).json({ error: 'Failed to fetch prompts' });
    }
  }

  async getPromptById(req, res) {
    try {
      const prompt = await Prompt.findOne({ tokenId: req.params.id });
      if (!prompt) {
        return res.status(404).json({ error: 'Prompt not found' });
      }

      // Increment views
      prompt.stats.views += 1;
      await prompt.save();

      res.json(prompt);

    } catch (error) {
      logger.error('Error fetching prompt:', error);
      res.status(500).json({ error: 'Failed to fetch prompt' });
    }
  }

  async purchasePrompt(req, res) {
    try {
      const { tokenId, buyer, price } = req.body;

      const prompt = await Prompt.findOne({ tokenId });
      if (!prompt) {
        return res.status(404).json({ error: 'Prompt not found' });
      }

      // Handle purchase through Origin SDK
      const origin = new OriginSDK();
      await origin.purchase(tokenId, buyer, price);

      // Update stats
      prompt.stats.purchases += 1;
      prompt.stats.totalRoyalties += (price * prompt.royaltyFee) / 10000;
      await prompt.save();

      res.json({ message: 'Purchase successful', prompt });

    } catch (error) {
      logger.error('Error purchasing prompt:', error);
      res.status(500).json({ error: 'Failed to purchase prompt' });
    }
  }
}

module.exports = new PromptController();

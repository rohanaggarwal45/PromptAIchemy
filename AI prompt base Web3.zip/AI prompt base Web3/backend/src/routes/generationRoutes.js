const express = require('express');
const router = express.Router();
const generationController = require('../controllers/generationController');
const { verifyWalletSignature } = require('../middleware/authMiddleware');

router.post('/', verifyWalletSignature, generationController.generateOutput);

module.exports = router;

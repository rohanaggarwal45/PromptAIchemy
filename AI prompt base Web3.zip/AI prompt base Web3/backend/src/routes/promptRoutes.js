const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const promptController = require('../controllers/promptController');
const { verifyWalletSignature, requireCreator } = require('../middleware/authMiddleware');

// Validation middleware
const validatePrompt = [
  body('title').notEmpty().trim().escape(),
  body('description').notEmpty().trim(),
  body('promptText').notEmpty(),
  body('promptType').isIn(['image', 'text']),
  body('royaltyFee').isInt({ min: 0, max: 10000 }),
  body('tags').isArray().optional()
];

// Routes
router.post('/', verifyWalletSignature, validatePrompt, promptController.createPrompt);
router.get('/', promptController.getPrompts);
router.get('/:id', promptController.getPromptById);
router.post('/:id/purchase', verifyWalletSignature, promptController.purchasePrompt);

module.exports = router;
